# Stopwatch Timer
Stopwatch timer on JS

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Instruction
Just open `index.html`

You can use *start*,*stop*,*reset* buttons for use stopwatch timer.

**[Live Demo](https://capwan.github.io/Stopwatch_timer/)**


